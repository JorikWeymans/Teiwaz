#pragma once
typedef unsigned int FontID;
typedef unsigned int TextureID;
typedef unsigned int AnimationID;
typedef unsigned int SceneID;
typedef unsigned int AnimatorID;